//
//  Copyright © 2019 PSPDFKit GmbH. All rights reserved.
//
//  The PSPDFKit Sample applications are licensed with a modified BSD license.
//  Please see License for details. This notice may not be removed from this file.
//

import SwiftUI
import PSPDFKit
import PSPDFKitUI
import PDFKit

struct ContentView: View {
    let documentURL = Bundle.main.url(forResource: "PSPDFKit 9 QuickStart Guide", withExtension: "pdf")!
    let configuration = PSPDFConfiguration {
        $0.pageTransition = .scrollContinuous
        $0.pageMode = .single
        $0.scrollDirection = .vertical
        $0.backgroundColor = .white
        $0.spreadFitting = .fill
    }
    var body: some View {
        VStack(alignment: .leading) {
            Text("PSPDFKit SwiftUI")
                .font(.largeTitle)
            HStack(alignment: .top) {
                Text("Made with ❤ at WWDC19")
                    .font(.title)
            }
            VStack(alignment: .leading) {
                HStack(alignment: .top) {
                    VStack(alignment: .center) {
                        Text("Apple's PDFKit").font(.title)
                        PDFKitView(url: documentURL)
                    }
                    VStack(alignment: .center) {
                        Text("PSPDFKit for iOS").font(.title)
                        PSPDFKitView(url: documentURL, configuration: configuration)
                    }
                }
            }
            .padding()
        }
        .padding()
    }
}

#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
