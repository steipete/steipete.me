//
//  ViewController.swift
//  PDFKit-Swift
//

import UIKit
import WebKit
import PDFKit

class ViewController: UIViewController {

    var filePath: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        drawPDF()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        /**
         Setting the document (`PDFDocument`) on the `PDFView` triggers a resize of the PDFView.
         If it is called when views have has not been laid out completely (for example: viewDidLoad) yet can result into a crash if built using iOS 12.2 SDK.
         */
        showPDF()
    }

    func drawPDF() {
        let documentsDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        filePath = (documentsDirectory as NSString).appendingPathComponent("PDFKit-Swift.pdf") as String

        let pdfTitle = "Generated PDF using PDFKit and Swift"

        let pdfMetadata = [
            // The name of the application creating the PDF.
            kCGPDFContextCreator: "Your iOS App",

            // The name of the PDF's author.
            kCGPDFContextAuthor: "Foo Bar",

            // Title of the PDF.
            kCGPDFContextTitle: "Lorem Ipsum",

            // Encrypts the document with the value as the owner password. Used to enable/disable different permissions.
            kCGPDFContextOwnerPassword: "myPassword123"
        ]

        UIGraphicsBeginPDFContextToFile(filePath, CGRect.zero, pdfMetadata)
        UIGraphicsBeginPDFPage()

        // Default size of the page is 612x72
        let pageSize = UIGraphicsGetPDFContextBounds().size
        let font = UIFont.preferredFont(forTextStyle: .title2)
        
        // Let's draw the title of the pdf on top of the page
        let attributedPDFTitle = NSAttributedString(string: pdfTitle, attributes: [NSAttributedString.Key.font: font])
        let titleStringSize = attributedPDFTitle.size()
        let titleStringRect = CGRect(x: (pageSize.width/2 - titleStringSize.width/2), y: 20, width: titleStringSize.width, height: titleStringSize.height)
        attributedPDFTitle.draw(in: titleStringRect)

        UIGraphicsEndPDFContext()
    }

    func showPDF() {
        view.backgroundColor = .black
        let pdfView = PDFView(frame: CGRect(x: view.center.x - 306, y: view.center.y - 396, width: 612, height: 792))
//        pdfView.autoScales = true
        view.addSubview(pdfView)

        let pdfDocument = PDFDocument(url: URL(fileURLWithPath: filePath))!
        pdfView.document = pdfDocument

        let page = pdfDocument.page(at: 0)!

        let imageAnnotation = PDFImageAnnotation(UIImage(named: "pspdfkit-logo"), bounds: CGRect(x: 200, y: 200, width: 100, height: 100), properties: nil)
        page.addAnnotation(imageAnnotation)
        pdfDocument.write(toFile: filePath)
    }
}
