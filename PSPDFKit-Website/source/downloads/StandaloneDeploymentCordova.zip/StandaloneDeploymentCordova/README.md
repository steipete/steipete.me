### README


The `MyApp` folder contains the the ready-to-run sample project.

1. `cd MyApp`
2. `cordova run <platform name>`

#### Here are the steps to integrate PSPDFKit for Web Standalone Deployment into Cordova apps.

1. Install Cordova: `npm install -g cordova`
2. Create a project: `cordova create MyApp`
3. `cd MyApp`
4. Add the [`cordova-plugin-httpd` plugin](https://www.npmjs.com/package/cordova-plugin-httpd): `cordova plugin add cordova-plugin-httpd`. This is needed as PSPDFKit for Web Standalone Deployment needs to run in localhost
5. Open the [www](/www) folder
6. Copy the `www/index.html` file to `MyApp/www`
7. Copy the `www/pspdfkit-example/` folder into `MyApp/www` 
8. Open `MyApp/www/pspdfkit-example/index.html` and enter your license key from the [customer portal](https://customers.pspdfkit.com/customers/sign_in)
9. Add the following to your `config.xml` 
    
```
	<allow-navigation href="http://*/*" />
    <allow-navigation href="https://*/*" />
```
10. Add a platform: `cordova platform add <platform name>`
11. Run your app: `cordova run <platform name>`