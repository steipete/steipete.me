cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "id": "cordova-plugin-httpd.CorHttpd",
        "file": "plugins/cordova-plugin-httpd/www/CorHttpd.js",
        "pluginId": "cordova-plugin-httpd",
        "clobbers": [
            "cordova.plugins.CorHttpd"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-httpd": "0.9.3",
    "cordova-plugin-whitelist": "1.3.2"
};
// BOTTOM OF METADATA
});